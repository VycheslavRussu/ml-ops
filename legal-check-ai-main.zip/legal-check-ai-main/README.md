# legal-check-ai
LegalCheckAI — это сервис, для проверки юридических документов
